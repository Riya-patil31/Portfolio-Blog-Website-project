const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/portfolioDB';
mongoose.connect(mongoUri).then(()=>console.log('MongoDB connected')).catch(err=>console.error(err));

const authRoutes = require('./routes/auth');
const postsRoutes = require('./routes/posts');
const contactRoutes = require('./routes/contact');

app.use('/api/auth', authRoutes);
app.use('/api/posts', postsRoutes);
app.use('/api/contact', contactRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log(`Server running on ${PORT}`));
