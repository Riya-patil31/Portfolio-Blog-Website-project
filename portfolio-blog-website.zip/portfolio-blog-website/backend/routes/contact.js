const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');

router.post('/', async (req,res)=>{
  const { name, email, message } = req.body;
  try{
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_USER,
      subject: `Contact from ${name}`,
      text: `Email: ${email}\n\nMessage:\n${message}`
    });
    res.json({ message: 'Message sent' });
  }catch(err){ res.status(500).json({ error: err.message }); }
});

module.exports = router;
