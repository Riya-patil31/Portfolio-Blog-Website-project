# Portfolio + Blog Website

A responsive Portfolio + Blog Website built with React (frontend) and Node.js + Express (backend).
Includes a contact form (sends email via Nodemailer) and a MongoDB-backed blog.

## Features
- Portfolio / Resume section
- Projects listing (sample cards included)
- Blog (create/read posts via API; sample posts included)
- Contact form with email integration (configure .env)
- Responsive and clean UI

## How to run
1. Clone repo
2. Backend:
   - cd backend
   - copy `.env.example` to `.env` and fill values
   - npm install
   - npm run dev
3. Frontend:
   - cd frontend
   - npm install
   - npm start

API base url: http://localhost:5000/api

Screenshots in `/screenshots/` (home, projects, blog, contact).
