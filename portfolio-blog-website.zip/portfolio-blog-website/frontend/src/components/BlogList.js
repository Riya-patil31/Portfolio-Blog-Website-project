import React, {useEffect, useState} from 'react';
import { api } from '../api';
export default function BlogList(){
  const [posts, setPosts] = useState([]);
  useEffect(()=>{ api.get('/posts').then(r=>setPosts(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h2>Blog Posts</h2>
      {posts.length===0 && <p>No posts yet. (Sample posts are included in the package)</p>}
      {posts.map(p => (
        <article key={p._id} style={{borderBottom:'1px solid #eee',padding:12}}>
          <h3>{p.title}</h3>
          <p>{p.excerpt}</p>
        </article>
      ))}
    </div>
  )
}
