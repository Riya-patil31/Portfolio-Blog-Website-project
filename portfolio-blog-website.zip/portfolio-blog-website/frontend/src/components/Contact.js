import React, {useState} from 'react';
import { api } from '../api';
export default function Contact(){
  const [form,setForm] = useState({name:'',email:'',message:''});
  const [status,setStatus] = useState('');
  async function submit(e){
    e.preventDefault();
    try{
      await api.post('/contact', form);
      setStatus('Message sent!');
      setForm({name:'',email:'',message:''});
    }catch(err){ setStatus('Failed to send'); }
  }
  return (
    <div>
      <h2>Contact Me</h2>
      <form onSubmit={submit} style={{display:'grid',gap:8,maxWidth:400}}>
        <input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Name" required />
        <input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Email" required />
        <textarea value={form.message} onChange={e=>setForm({...form,message:e.target.value})} placeholder="Message" required />
        <button type="submit">Send</button>
      </form>
      <p>{status}</p>
    </div>
  )
}
