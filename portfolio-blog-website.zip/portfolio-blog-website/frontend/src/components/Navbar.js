import React from 'react';
export default function Navbar({onNav}){
  return (
    <nav style={{display:'flex',gap:16,padding:16,background:'#1e3a8a',color:'#fff',alignItems:'center'}}>
      <div style={{fontWeight:700,fontSize:18}}>Puja Yeshi</div>
      <button onClick={()=>onNav('home')} style={{background:'transparent',color:'#fff',border:'none'}}>Home</button>
      <button onClick={()=>onNav('projects')} style={{background:'transparent',color:'#fff',border:'none'}}>Projects</button>
      <button onClick={()=>onNav('blog')} style={{background:'transparent',color:'#fff',border:'none'}}>Blog</button>
      <button onClick={()=>onNav('contact')} style={{background:'transparent',color:'#fff',border:'none'}}>Contact</button>
    </nav>
  )
}
