import React from 'react';
export default function Home(){
  return (
    <div>
      <h1>Hi, I'm Puja Yeshi</h1>
      <p>TYBCA student. Web developer (React, Node.js). I build projects and write about what I learn.</p>
      <h3>Skills</h3>
      <ul>
        <li>HTML, CSS, JavaScript, React</li>
        <li>Node.js, Express, MongoDB</li>
        <li>C++, Java</li>
      </ul>
      <a href="#">Download Resume (placeholder)</a>
    </div>
  )
}
