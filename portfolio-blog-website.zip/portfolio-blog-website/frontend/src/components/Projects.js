import React from 'react';
export default function Projects(){
  const projects = [
    {title:'Blog Website', desc:'React + Node + MongoDB', link:'#'},
    {title:'Portfolio', desc:'React static site', link:'#'},
    {title:'Inventory System', desc:'Node + MySQL', link:'#'}
  ];
  return (
    <div>
      <h2>Projects</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12}}>
        {projects.map((p,i)=> (
          <div key={i} style={{padding:12,border:'1px solid #ddd',borderRadius:8,background:'#fff'}}>
            <h4>{p.title}</h4>
            <p>{p.desc}</p>
            <a href={p.link}>View on GitHub</a>
          </div>
        ))}
      </div>
    </div>
  )
}
