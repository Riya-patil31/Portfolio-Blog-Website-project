import React from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Projects from './components/Projects';
import BlogList from './components/BlogList';
import Contact from './components/Contact';

export default function App(){
  const [route, setRoute] = React.useState('home');
  return (
    <div>
      <Navbar onNav={r=>setRoute(r)} />
      <main style={{padding:20}}>
        {route==='home' && <Home />}
        {route==='projects' && <Projects />}
        {route==='blog' && <BlogList />}
        {route==='contact' && <Contact />}
      </main>
    </div>
  )
}
